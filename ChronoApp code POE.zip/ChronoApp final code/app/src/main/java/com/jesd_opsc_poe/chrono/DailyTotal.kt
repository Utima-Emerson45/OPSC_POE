package com.jesd_opsc_poe.chrono

import java.util.Date

data class DailyTotal(val time : Float, val date : String?)
