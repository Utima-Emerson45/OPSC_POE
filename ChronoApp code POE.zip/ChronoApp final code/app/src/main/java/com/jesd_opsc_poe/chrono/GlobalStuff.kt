package com.jesd_opsc_poe.chrono
object Global{
    val dailyGoal: DailyGoal = DailyGoal()
}