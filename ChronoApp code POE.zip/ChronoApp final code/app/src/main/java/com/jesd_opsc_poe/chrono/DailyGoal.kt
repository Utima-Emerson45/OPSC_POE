package com.jesd_opsc_poe.chrono

data class DailyGoal(
    var min: String? = null,
    var max: String? = null,
    var date: String? = null,
    var userKey: String? = null,
)