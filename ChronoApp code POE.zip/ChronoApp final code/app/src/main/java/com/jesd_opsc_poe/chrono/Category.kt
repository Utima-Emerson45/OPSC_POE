package com.jesd_opsc_poe.chrono

data class Category(
    var categoryName: String? = null,
    var categoryTime: String? = null)